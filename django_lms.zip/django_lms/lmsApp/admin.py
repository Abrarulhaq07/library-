from django.contrib import admin
from lmsApp import models

# Register your models here.
# admin.site.register(models.Groups)
